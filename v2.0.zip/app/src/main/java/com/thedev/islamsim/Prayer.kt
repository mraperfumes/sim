package com.thedev.islamsim

import android.annotation.SuppressLint
import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Geocoder
import android.location.Location
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.CalculationParameters
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.Madhab
import com.batoulapps.adhan.PrayerTimes
import com.batoulapps.adhan.data.DateComponents
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

class City(val name: String, val country: String, val lat: Double, val lng: Double, val tz: String)

val CITIES = listOf(
    City("Makkah", "Saudi Arabia", 21.42, 39.83, "Asia/Riyadh"), City("Madinah", "Saudi Arabia", 24.47, 39.61, "Asia/Riyadh"),
    City("Riyadh", "Saudi Arabia", 24.71, 46.68, "Asia/Riyadh"), City("Jeddah", "Saudi Arabia", 21.54, 39.17, "Asia/Riyadh"),
    City("Kano", "Nigeria", 12.00, 8.52, "Africa/Lagos"), City("Kaduna", "Nigeria", 10.52, 7.44, "Africa/Lagos"),
    City("Abuja", "Nigeria", 9.06, 7.49, "Africa/Lagos"), City("Lagos", "Nigeria", 6.52, 3.38, "Africa/Lagos"),
    City("Sokoto", "Nigeria", 13.06, 5.24, "Africa/Lagos"), City("Katsina", "Nigeria", 12.99, 7.60, "Africa/Lagos"),
    City("Zaria", "Nigeria", 11.08, 7.71, "Africa/Lagos"), City("Maiduguri", "Nigeria", 11.85, 13.16, "Africa/Lagos"),
    City("Bauchi", "Nigeria", 10.31, 9.84, "Africa/Lagos"), City("Jos", "Nigeria", 9.90, 8.86, "Africa/Lagos"),
    City("Ilorin", "Nigeria", 8.50, 4.55, "Africa/Lagos"), City("Ibadan", "Nigeria", 7.38, 3.95, "Africa/Lagos"),
    City("Niamey", "Niger", 13.51, 2.11, "Africa/Niamey"), City("Accra", "Ghana", 5.60, -0.19, "Africa/Accra"),
    City("Dakar", "Senegal", 14.72, -17.47, "Africa/Dakar"), City("Bamako", "Mali", 12.64, -8.00, "Africa/Bamako"),
    City("Abidjan", "Côte d'Ivoire", 5.36, -4.01, "Africa/Abidjan"), City("N'Djamena", "Chad", 12.13, 15.05, "Africa/Ndjamena"),
    City("Khartoum", "Sudan", 15.50, 32.56, "Africa/Khartoum"), City("Cairo", "Egypt", 30.04, 31.24, "Africa/Cairo"),
    City("Tripoli", "Libya", 32.89, 13.19, "Africa/Tripoli"), City("Tunis", "Tunisia", 36.81, 10.18, "Africa/Tunis"),
    City("Algiers", "Algeria", 36.75, 3.06, "Africa/Algiers"), City("Casablanca", "Morocco", 33.57, -7.59, "Africa/Casablanca"),
    City("Nairobi", "Kenya", -1.29, 36.82, "Africa/Nairobi"), City("Dar es Salaam", "Tanzania", -6.79, 39.21, "Africa/Dar_es_Salaam"),
    City("Addis Ababa", "Ethiopia", 9.03, 38.74, "Africa/Addis_Ababa"), City("Mogadishu", "Somalia", 2.05, 45.32, "Africa/Mogadishu"),
    City("Johannesburg", "South Africa", -26.20, 28.05, "Africa/Johannesburg"),
    City("Dubai", "UAE", 25.20, 55.27, "Asia/Dubai"), City("Doha", "Qatar", 25.29, 51.53, "Asia/Qatar"),
    City("Kuwait City", "Kuwait", 29.38, 47.99, "Asia/Kuwait"), City("Muscat", "Oman", 23.59, 58.41, "Asia/Muscat"),
    City("Amman", "Jordan", 31.95, 35.93, "Asia/Amman"), City("Baghdad", "Iraq", 33.31, 44.36, "Asia/Baghdad"),
    City("Tehran", "Iran", 35.69, 51.39, "Asia/Tehran"), City("Istanbul", "Türkiye", 41.01, 28.98, "Europe/Istanbul"),
    City("Karachi", "Pakistan", 24.86, 67.01, "Asia/Karachi"), City("Lahore", "Pakistan", 31.55, 74.34, "Asia/Karachi"),
    City("Islamabad", "Pakistan", 33.68, 73.05, "Asia/Karachi"), City("Kabul", "Afghanistan", 34.53, 69.17, "Asia/Kabul"),
    City("Delhi", "India", 28.61, 77.21, "Asia/Kolkata"), City("Mumbai", "India", 19.08, 72.88, "Asia/Kolkata"),
    City("Dhaka", "Bangladesh", 23.81, 90.41, "Asia/Dhaka"), City("Jakarta", "Indonesia", -6.21, 106.85, "Asia/Jakarta"),
    City("Kuala Lumpur", "Malaysia", 3.14, 101.69, "Asia/Kuala_Lumpur"), City("Singapore", "Singapore", 1.35, 103.82, "Asia/Singapore"),
    City("London", "United Kingdom", 51.51, -0.13, "Europe/London"), City("Paris", "France", 48.86, 2.35, "Europe/Paris"),
    City("Berlin", "Germany", 52.52, 13.40, "Europe/Berlin"), City("New York", "USA", 40.71, -74.01, "America/New_York"),
    City("Houston", "USA", 29.76, -95.37, "America/Chicago"), City("Los Angeles", "USA", 34.05, -118.24, "America/Los_Angeles"),
    City("Toronto", "Canada", 43.65, -79.38, "America/Toronto"), City("Sydney", "Australia", -33.87, 151.21, "Australia/Sydney")
)

object PrayerCalc {
    val NAMES = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
    val METHODS = listOf(
        "MUSLIM_WORLD_LEAGUE" to "Muslim World League", "EGYPTIAN" to "Egyptian General Authority",
        "KARACHI" to "Univ. of Islamic Sciences, Karachi", "UMM_AL_QURA" to "Umm al-Qura, Makkah",
        "DUBAI" to "Dubai", "QATAR" to "Qatar", "KUWAIT" to "Kuwait", "SINGAPORE" to "Singapore",
        "NORTH_AMERICA" to "ISNA (North America)", "MOON_SIGHTING_COMMITTEE" to "Moonsighting Committee"
    )

    private fun params(): CalculationParameters {
        val p = try { CalculationMethod.valueOf(S.method).parameters } catch (e: Exception) { CalculationMethod.MUSLIM_WORLD_LEAGUE.parameters }
        p.madhab = if (S.hanafi) Madhab.HANAFI else Madhab.SHAFI
        return p
    }

    private fun day(offset: Int, now: Long): PrayerTimes {
        val cal = Calendar.getInstance(TimeZone.getTimeZone(S.locTz))
        cal.timeInMillis = now + offset * 86_400_000L
        val dc = DateComponents(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
        return PrayerTimes(Coordinates(S.lat, S.lng), dc, params())
    }

    /** (prayerIndex, epochMillis) for yesterday, today and tomorrow, in order. */
    fun timeline(now: Long): List<Pair<Int, Long>> = (-1..1).flatMap { off ->
        val t = day(off, now)
        listOf(t.fajr, t.dhuhr, t.asr, t.maghrib, t.isha).mapIndexed { i, d -> i to d.time }
    }

    fun today(now: Long): List<Long> = day(0, now).let { t -> listOf(t.fajr, t.dhuhr, t.asr, t.maghrib, t.isha).map { it.time } }

    fun fmt(ms: Long): String =
        SimpleDateFormat("h:mm a", Locale.getDefault()).apply { timeZone = TimeZone.getTimeZone(S.locTz) }.format(ms)
}

object AdhanState { var active by mutableStateOf(false) }

object Notifier {
    const val CH_ADHAN = "adhan_playing"
    const val CH_FALLBACK = "adhan_alert"

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_ADHAN, "Adhan playback", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null); description = "Shown while the Adhan is playing"
        })
        nm.createNotificationChannel(NotificationChannel(CH_FALLBACK, "Prayer time alerts", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Used if the Adhan cannot start"
        })
    }

    fun hasBuiltInAdhan(ctx: Context) = ctx.resources.getIdentifier("adhan", "raw", ctx.packageName) != 0
    fun onlineAdhanFile(ctx: Context): java.io.File? =
        AdhanLibrary.file(ctx, S.adhanOnlineId).takeIf { it.exists() && it.length() > 20_000 }
    fun hasRealAdhan(ctx: Context) = S.adhanUri.isNotEmpty() || onlineAdhanFile(ctx) != null || hasBuiltInAdhan(ctx)

    fun adhanUri(ctx: Context): Uri {
        if (S.adhanUri.isNotEmpty()) return Uri.parse(S.adhanUri)
        onlineAdhanFile(ctx)?.let { return Uri.fromFile(it) }
        val id = ctx.resources.getIdentifier("adhan", "raw", ctx.packageName)
        if (id != 0) return Uri.parse("android.resource://${ctx.packageName}/$id")
        return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    }

    @SuppressLint("MissingPermission")
    fun fallback(ctx: Context, idx: Int) {
        ensureChannels(ctx)
        val open = PendingIntent.getActivity(ctx, 2, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, CH_FALLBACK).setSmallIcon(R.drawable.ic_stat_adhan)
            .setContentTitle("Time for ${PrayerCalc.NAMES[idx]}").setContentText(S.locName.ifEmpty { "Prayer time" })
            .setContentIntent(open).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM).build()
        try { NotificationManagerCompat.from(ctx).notify(3000 + idx, n) } catch (_: SecurityException) { }
    }
}

object AdhanScheduler {
    private fun pending(ctx: Context, idx: Int, at: Long): PendingIntent = PendingIntent.getBroadcast(
        ctx, 7001, Intent(ctx, AlarmReceiver::class.java).setAction(AlarmReceiver.ACTION).putExtra("idx", idx).putExtra("at", at),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun canExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        return (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
    }

    /** Schedules ONE alarm: the next enabled prayer. Every alarm (and boot/time change) schedules the following one. */
    fun scheduleNext(ctx: Context) {
        S.init(ctx)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!S.master || !S.hasLoc) { am.cancel(pending(ctx, 0, 0)); return }
        val now = System.currentTimeMillis()
        val next = PrayerCalc.timeline(now).firstOrNull { it.second > now + 1000 && S.prayerOn(it.first) }
        if (next == null) { am.cancel(pending(ctx, 0, 0)); return }
        val pi = pending(ctx, next.first, next.second)
        try {
            if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.second, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.second, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.second, pi)
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    companion object { const val ACTION = "com.thedev.islamsim.ADHAN_ALARM" }

    override fun onReceive(ctx: Context, intent: Intent) {
        S.init(ctx)
        if (intent.action == ACTION) {
            val idx = intent.getIntExtra("idx", 0).coerceIn(0, 4)
            val at = intent.getLongExtra("at", 0L)
            val fresh = kotlin.math.abs(System.currentTimeMillis() - at) < 10 * 60_000L
            if (S.master && S.prayerOn(idx) && fresh) {
                try {
                    ContextCompat.startForegroundService(ctx, Intent(ctx, AdhanService::class.java).putExtra("idx", idx))
                } catch (e: Exception) { Notifier.fallback(ctx, idx) }
            }
        }
        AdhanScheduler.scheduleNext(ctx)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        S.init(ctx)
        AdhanScheduler.scheduleNext(ctx)
    }
}

class AdhanService : Service() {
    companion object { const val ACTION_STOP = "com.thedev.islamsim.STOP_ADHAN"; const val NOTIF_ID = 4001 }
    private var mp: MediaPlayer? = null
    private var am: AudioManager? = null
    private val focusListener = AudioManager.OnAudioFocusChangeListener { }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        S.init(this)
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val idx = (intent?.getIntExtra("idx", 0) ?: 0).coerceIn(0, 4)
        Notifier.ensureChannels(this)
        val stop = PendingIntent.getService(this, 1, Intent(this, AdhanService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, Notifier.CH_ADHAN).setSmallIcon(R.drawable.ic_stat_adhan)
            .setContentTitle("Time for ${PrayerCalc.NAMES[idx]}").setContentText(S.locName.ifEmpty { "Adhan" })
            .setContentIntent(open).addAction(0, "Stop", stop).setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(NOTIF_ID, n)
        } catch (e: Exception) { Notifier.fallback(this, idx); stopSelf(); return START_NOT_STICKY }
        AdhanState.active = true
        play()
        return START_NOT_STICKY
    }

    private fun play() {
        release()
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        @Suppress("DEPRECATION")
        am?.requestAudioFocus(focusListener, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            p.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(this, Notifier.adhanUri(this))
            p.setOnPreparedListener { it.start() }
            p.setOnCompletionListener { stopSelf() }
            p.setOnErrorListener { _, _, _ -> stopSelf(); true }
            p.prepareAsync()
            mp = p
        } catch (e: Exception) { stopSelf() }
    }

    private fun release() { try { mp?.release() } catch (_: Exception) { }; mp = null }

    override fun onDestroy() {
        release()
        @Suppress("DEPRECATION") am?.abandonAudioFocus(focusListener)
        AdhanState.active = false
        @Suppress("DEPRECATION") stopForeground(true)
        super.onDestroy()
    }
}

class Loc(val name: String, val lat: Double, val lng: Double, val tz: String)

object LocationHelper {
    @SuppressLint("MissingPermission")
    fun detect(ctx: Context, cb: (Loc?) -> Unit) {
        val client = LocationServices.getFusedLocationProviderClient(ctx)
        val main = Handler(Looper.getMainLooper())
        fun finish(loc: Location?) {
            if (loc == null) { cb(null); return }
            Thread {
                var name = String.format(Locale.US, "%.2f, %.2f", loc.latitude, loc.longitude)
                try {
                    @Suppress("DEPRECATION")
                    val list = Geocoder(ctx, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)
                    val a = list?.firstOrNull()
                    if (a != null) {
                        val city = a.locality ?: a.subAdminArea ?: a.adminArea
                        val n = listOfNotNull(city, a.countryName).joinToString(", ")
                        if (n.isNotEmpty()) name = n
                    }
                } catch (_: Exception) { }
                main.post { cb(Loc(name, loc.latitude, loc.longitude, TimeZone.getDefault().id)) }
            }.start()
        }
        client.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
            .addOnSuccessListener { loc ->
                if (loc != null) finish(loc)
                else client.lastLocation.addOnSuccessListener { finish(it) }.addOnFailureListener { cb(null) }
            }
            .addOnFailureListener { cb(null) }
    }
}
