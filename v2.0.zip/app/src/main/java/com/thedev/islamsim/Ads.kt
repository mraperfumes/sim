package com.thedev.islamsim

import android.app.Activity
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

/**
 * Rewarded ads ONLY. Ads are strictly optional and user-initiated (the "Support Islam Sim" button).
 * They are never shown in the Quran reader, during recitation, or during Adhan playback.
 */
object Ads {
    var ready by mutableStateOf(false)
    var loading by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var privacyOptionsRequired by mutableStateOf(false)

    private var rewarded: RewardedAd? = null
    private var sdkStarted = false

    /** Consent (UMP) first, then initialise the SDK and preload one rewarded ad. */
    fun start(activity: Activity) {
        val info = UserMessagingPlatform.getConsentInformation(activity)
        info.requestConsentInfoUpdate(activity, ConsentRequestParameters.Builder().build(), {
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ ->
                privacyOptionsRequired =
                    info.privacyOptionsRequirementStatus == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
                if (info.canRequestAds()) initSdk(activity)
            }
        }, { _ ->
            if (info.canRequestAds()) initSdk(activity)
        })
        // Consent from a previous session may already allow ads.
        if (info.canRequestAds()) initSdk(activity)
    }

    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { _ -> }
    }

    private fun initSdk(ctx: Context) {
        if (sdkStarted) return
        sdkStarted = true
        MobileAds.initialize(ctx.applicationContext) { load(ctx) }
    }

    fun load(ctx: Context) {
        if (!sdkStarted || loading || rewarded != null) return
        loading = true; ready = false
        RewardedAd.load(ctx.applicationContext, BuildConfig.REWARDED_UNIT_ID, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { rewarded = ad; ready = true; loading = false; message = null }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewarded = null; ready = false; loading = false
                    message = "No ad available right now. Please try again later."
                }
            })
    }

    /** Only call from a user tap, and never while Quran audio or Adhan is playing. */
    fun show(activity: Activity, onReward: () -> Unit) {
        if (Recitation.isPlaying || AdhanState.active) { message = "Ads are never shown during recitation or Adhan."; return }
        val ad = rewarded ?: run { message = "Ad not ready yet."; load(activity); return }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { rewarded = null; ready = false; load(activity) }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                rewarded = null; ready = false; message = "Couldn't show the ad."; load(activity)
            }
        }
        ad.show(activity) { _ -> onReward() }
    }
}
