package com.thedev.islamsim

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.snapshotFlow

@OptIn(kotlinx.coroutines.FlowPreview::class)
@Composable
fun QuranTab(onOpen: (Int, Int) -> Unit) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var sub by rememberSaveable { mutableIntStateOf(0) }
    var filter by rememberSaveable { mutableStateOf("") }
    var query by rememberSaveable { mutableStateOf("") }
    var hits by remember { mutableStateOf<List<Hit>>(emptyList()) }

    LaunchedEffect(query, Quran.status) {
        delay(300)
        hits = withContext(Dispatchers.Default) { Quran.search(query) }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Txt("Holy Quran", 24.sp, g.gold, bold = true, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 10.dp)) {
            GlassChip("Surahs", sub == 0) { sub = 0 }
            GlassChip("Bookmarks", sub == 1) { sub = 1 }
            GlassChip("Search", sub == 2) { sub = 2 }
        }
        when (Quran.status) {
            "loading", "idle" -> Column(Modifier.fillMaxWidth().glass().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = g.gold)
                Txt("Downloading Quran text (first time only)…", 14.sp, g.dim, modifier = Modifier.padding(top = 12.dp))
            }
            "error" -> Column(Modifier.fillMaxWidth().glass().padding(20.dp)) {
                Txt(Quran.error ?: "Error", 14.sp, g.text)
                GoldButton("Retry", Modifier.padding(top = 12.dp)) { scope.launch { Quran.load(ctx, true) } }
            }
            else -> {
                Quran.warning?.let { Txt(it, 12.sp, g.dim, modifier = Modifier.padding(bottom = 6.dp)) }
                when (sub) {
                    0 -> {
                        OutlinedTextField(filter, { filter = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                            placeholder = { Txt("Filter by name or number", 14.sp, g.dim) },
                            colors = fieldColors(), textStyle = TextStyle(color = g.text, fontSize = 15.sp))
                        val list = remember(filter, Quran.surahs) {
                            val f = filter.trim().lowercase()
                            if (f.isEmpty()) Quran.surahs else Quran.surahs.filter {
                                it.english.lowercase().contains(f) || it.number.toString() == f || it.meaning.lowercase().contains(f)
                            }
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
                            items(list, key = { it.number }) { s ->
                                Row(Modifier.fillMaxWidth().glass(18.dp).clickable { onOpen(s.number, 0) }.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Txt("${s.number}", 15.sp, g.gold, bold = true, modifier = Modifier.width(36.dp))
                                    Column(Modifier.weight(1f)) {
                                        Txt(s.english, 16.sp, g.text, bold = true)
                                        Txt("${s.meaning} • ${s.type} • ${s.ayahCount} ayahs" + if (s.number in Audio.downloaded) " • ⬇" else "", 12.sp, g.dim)
                                    }
                                    Txt(s.arabicName, 20.sp, g.gold, font = arabicFont())
                                }
                            }
                        }
                    }
                    1 -> {
                        val bms = S.bookmarks.mapNotNull { k -> k.split(":").let { p -> p.getOrNull(0)?.toIntOrNull()?.let { s -> p.getOrNull(1)?.toIntOrNull()?.let { a -> s to a } } } }
                            .sortedWith(compareBy({ it.first }, { it.second }))
                        if (bms.isEmpty()) Txt("No bookmarks yet. Tap ☆ on any ayah.", 14.sp, g.dim)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 6.dp)) {
                            items(bms, key = { "${it.first}:${it.second}" }) { (s, a) ->
                                Column(Modifier.fillMaxWidth().glass(18.dp).clickable { onOpen(s, a - 1) }.padding(14.dp)) {
                                    Txt("${Quran.surahs[s - 1].english} • Ayah $a", 15.sp, g.gold, bold = true)
                                    Txt(Quran.arabic[s - 1][a - 1], 18.sp, g.text, align = TextAlign.Right, font = arabicFont(),
                                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                                }
                            }
                        }
                    }
                    else -> {
                        OutlinedTextField(query, { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                            placeholder = { Txt("Search Arabic, English or Hausa", 14.sp, g.dim) },
                            colors = fieldColors(), textStyle = TextStyle(color = g.text, fontSize = 15.sp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
                            items(hits) { h ->
                                Column(Modifier.fillMaxWidth().glass(18.dp).clickable { onOpen(h.surah, h.ayah - 1) }.padding(14.dp)) {
                                    Txt("${Quran.surahs[h.surah - 1].english} ${h.surah}:${h.ayah}", 14.sp, g.gold, bold = true)
                                    Txt(h.arabic, 18.sp, g.text, align = TextAlign.Right, font = arabicFont(),
                                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                                    h.translation?.let { Txt(it, 13.sp, g.dim, modifier = Modifier.padding(top = 4.dp)) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun fieldColors(): TextFieldColors {
    val g = LocalGlass.current
    return OutlinedTextFieldDefaults.colors(
        focusedBorderColor = g.gold, unfocusedBorderColor = g.border, cursorColor = g.gold,
        focusedTextColor = g.text, unfocusedTextColor = g.text)
}

@OptIn(kotlinx.coroutines.FlowPreview::class)
@Composable
fun Reader(surah: Int, startIndex: Int, onBack: () -> Unit) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val font = arabicFont()
    if (Quran.surahs.size != 114) { onBack(); return }
    val meta = Quran.surahs[surah - 1]
    val ayahs = Quran.arabic[surah - 1]
    val state = rememberLazyListState(initialFirstVisibleItemIndex = if (startIndex > 0) startIndex + 1 else 0)
    var jump by remember { mutableStateOf(false) }
    var jumpText by remember { mutableStateOf("") }

    LaunchedEffect(surah) {
        snapshotFlow { state.firstVisibleItemIndex }.debounce(400).collect { S.setLast(surah, (it - 1).coerceAtLeast(0)) }
    }
    LaunchedEffect(Unit) { while (true) { Recitation.tick(); delay(500) } }
    LaunchedEffect(Recitation.error) { Recitation.error?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); Recitation.error = null } }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            GlassChip("‹ Back", false) { onBack() }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Txt(meta.english, 17.sp, g.text, bold = true)
                Txt("${meta.meaning} • ${meta.ayahCount} ayahs", 11.sp, g.dim)
            }
            GlassChip("A−", false) { S.changeArabicSize(S.arabicSize - 2) }
            Spacer(Modifier.width(6.dp))
            GlassChip("A+", false) { S.changeArabicSize(S.arabicSize + 2) }
        }
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip("English", S.showEn && Quran.english != null) { S.changeShowEn(!S.showEn) }
            GlassChip("Hausa", S.showHa && Quran.hausa != null) { S.changeShowHa(!S.showHa) }
            GlassChip("Go to ayah", false) { jump = true }
        }
        LazyColumn(Modifier.weight(1f), state = state, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Column(Modifier.fillMaxWidth().glass().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Txt(meta.arabicName, 28.sp, g.gold, font = font)
                    Txt("${meta.english} • ${meta.type}", 13.sp, g.dim)
                }
            }
            itemsIndexed(ayahs) { i, text ->
                val n = i + 1
                val marked = "$surah:$n" in S.bookmarks
                Column(Modifier.fillMaxWidth().glass(18.dp).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Txt("$n", 13.sp, g.gold, bold = true)
                        Spacer(Modifier.weight(1f))
                        Txt(if (marked) "★" else "☆", 24.sp, g.gold, modifier = Modifier.clickable { S.toggleBookmark(surah, n) }.padding(4.dp))
                    }
                    Txt(text, S.arabicSize.sp, g.text, align = TextAlign.Right, font = font, lineHeight = (S.arabicSize * 1.9f).sp,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
                    if (S.showEn) Quran.english?.let { Txt(it[surah - 1][i], 14.sp, g.dim, modifier = Modifier.padding(top = 4.dp)) }
                    if (S.showHa) Quran.hausa?.let { Txt(it[surah - 1][i], 14.sp, g.dim, modifier = Modifier.padding(top = 4.dp)) }
                }
            }
        }
        // Audio bar (no ads anywhere in the reader)
        val here = Recitation.surah == surah
        var drag by remember { mutableStateOf<Float?>(null) }
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp).glass(24.dp).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GoldButton(if (here && Recitation.isPlaying) "⏸ Pause" else if (here) "▶ Resume" else "▶ Play") {
                    if (here) Recitation.toggle() else scope.launch { Recitation.play(ctx, surah, meta.english) }
                }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Txt(Audio.RECITER_NAME, 13.sp, g.text, bold = true)
                    Txt(if (here && Recitation.buffering) "Buffering…" else "Recitation", 11.sp, g.dim)
                }
                val prog = Audio.progress[surah]
                when {
                    prog != null -> Txt("${(prog * 100).toInt()}%", 13.sp, g.gold)
                    surah in Audio.downloaded -> GlassChip("Offline ✓", true) { Audio.delete(ctx, surah) }
                    else -> GlassChip("⬇ Download", false) {
                        scope.launch { if (!Audio.download(ctx, surah)) Toast.makeText(ctx, "Download failed. Check your connection.", Toast.LENGTH_LONG).show() }
                    }
                }
            }
            if (here && Recitation.duration > 0) {
                Slider(value = drag ?: Recitation.position.toFloat(), onValueChange = { drag = it },
                    onValueChangeFinished = { drag?.let { Recitation.seek(it.toLong()) }; drag = null },
                    valueRange = 0f..Recitation.duration.toFloat(),
                    colors = SliderDefaults.colors(thumbColor = g.gold, activeTrackColor = g.gold, inactiveTrackColor = g.border))
            }
        }
    }

    if (jump) AlertDialog(
        onDismissRequest = { jump = false },
        title = { Text("Go to ayah (1–${ayahs.size})") },
        text = { OutlinedTextField(jumpText, { jumpText = it.filter(Char::isDigit) }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) },
        confirmButton = {
            TextButton(onClick = {
                val n = jumpText.toIntOrNull()
                jump = false
                if (n != null && n in 1..ayahs.size) scope.launch { state.animateScrollToItem(n) }
            }) { Text("Go") }
        },
        dismissButton = { TextButton(onClick = { jump = false }) { Text("Cancel") } }
    )
}
