package com.thedev.islamsim

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.util.Locale

private fun displayName(ctx: android.content.Context, uri: Uri): String = try {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    } ?: "Selected audio"
} catch (e: Exception) { "Selected audio" }

@Composable
fun PrayerTab() {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val now = rememberNow()
    val scope = rememberCoroutineScope()
    var showCities by remember { mutableStateOf(false) }
    var locating by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var methodMenu by remember { mutableStateOf(false) }

    fun detect() {
        locating = true; msg = null
        LocationHelper.detect(ctx) { loc ->
            locating = false
            if (loc == null) msg = "Couldn't get your location. Turn on GPS or choose a city."
            else { S.setLocation(loc.name, loc.lat, loc.lng, loc.tz, true); AdhanScheduler.scheduleNext(ctx) }
        }
    }
    val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) detect() else msg = "Location permission denied. Choose a city manually."
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok) Toast.makeText(ctx, "Notifications are off – Adhan alerts may not show.", Toast.LENGTH_LONG).show()
    }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            S.setAdhan(uri.toString(), displayName(ctx, uri))
        }
    }

    val notifOk = remember(now / 2000) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val exactOk = remember(now / 2000) { AdhanScheduler.canExact(ctx) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Txt("Prayer times", 24.sp, g.gold, bold = true)

        // Location
        Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
            Txt("Location", 12.sp, g.dim)
            Txt(if (S.hasLoc) S.locName else "Not set", 17.sp, g.text, bold = true)
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GoldButton(if (locating) "Locating…" else "Use GPS", enabled = !locating) {
                    val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    if (fine || coarse) detect()
                    else locLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                }
                GlassChip("Choose city", false, Modifier.align(Alignment.CenterVertically)) { showCities = true }
            }
            msg?.let { Txt(it, 12.sp, g.dim, modifier = Modifier.padding(top = 6.dp)) }
        }

        // Times
        if (S.hasLoc) {
            val times = remember(now / 3_600_000L, S.lat, S.lng, S.method, S.hanafi, S.locTz) { PrayerCalc.today(now) }
            val next = remember(now / 1000, times) { PrayerCalc.timeline(now).firstOrNull { it.second > now } }
            Column(Modifier.fillMaxWidth().glass().padding(8.dp)) {
                PrayerCalc.NAMES.forEachIndexed { i, name ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Txt(name, 17.sp, if (next?.first == i) g.gold else g.text, bold = next?.first == i, modifier = Modifier.weight(1f))
                        Txt(PrayerCalc.fmt(times[i]), 17.sp, if (next?.first == i) g.gold else g.text, bold = next?.first == i)
                        Switch(checked = S.prayerOn(i), onCheckedChange = { S.setPrayer(i, it); AdhanScheduler.scheduleNext(ctx) },
                            modifier = Modifier.padding(start = 10.dp),
                            colors = SwitchDefaults.colors(checkedTrackColor = g.accent, checkedThumbColor = Color_White))
                    }
                }
            }
        }

        // Calculation
        Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
            Txt("Calculation method", 12.sp, g.dim)
            Box {
                Txt(PrayerCalc.METHODS.firstOrNull { it.first == S.method }?.second ?: S.method, 16.sp, g.text, bold = true,
                    modifier = Modifier.clickable { methodMenu = true }.padding(vertical = 8.dp))
                DropdownMenu(methodMenu, { methodMenu = false }) {
                    PrayerCalc.METHODS.forEach { (id, label) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { S.changeMethod(id); methodMenu = false; AdhanScheduler.scheduleNext(ctx) })
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                GlassChip("Asr: Standard (Shafi'i/Maliki/Hanbali)", !S.hanafi) { S.changeHanafi(false); AdhanScheduler.scheduleNext(ctx) }
            }
            Row(Modifier.padding(top = 6.dp)) { GlassChip("Asr: Hanafi", S.hanafi) { S.changeHanafi(true); AdhanScheduler.scheduleNext(ctx) } }
        }

        // Adhan & alerts
        Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt("Adhan alerts", 16.sp, g.text, bold = true)
                    Txt("Plays the Adhan at prayer times, even when the app is closed", 12.sp, g.dim)
                }
                Switch(checked = S.master, onCheckedChange = { S.changeMaster(it); AdhanScheduler.scheduleNext(ctx) },
                    colors = SwitchDefaults.colors(checkedTrackColor = g.accent, checkedThumbColor = Color_White))
            }
            Txt("Adhan voice", 12.sp, g.dim, modifier = Modifier.padding(top = 12.dp))
            AdhanLibrary.VOICES.forEach { v ->
                val have = v.id in AdhanLibrary.downloaded
                val sel = S.adhanUri.isEmpty() && S.adhanOnlineId == v.id
                Row(Modifier.fillMaxWidth().clickable {
                    S.changeAdhanOnline(v.id)
                    if (S.adhanUri.isNotEmpty()) S.setAdhan("", "")
                    scope.launch { AdhanLibrary.ensure(ctx, v.id) }
                }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Txt(if (sel) "◉" else "○", 18.sp, g.gold, modifier = Modifier.width(28.dp))
                    Txt(v.name, 15.sp, g.text, bold = sel, modifier = Modifier.weight(1f))
                    Txt(when { AdhanLibrary.busy == v.id -> "Downloading…"; have -> "✓ Ready"; else -> "⬇ Tap to get" }, 12.sp, g.dim)
                }
            }
            AdhanLibrary.error?.let { Txt(it, 12.sp, g.dim, modifier = Modifier.padding(top = 4.dp)) }
            Txt("Or use your own audio file", 12.sp, g.dim, modifier = Modifier.padding(top = 12.dp))
            if (S.adhanUri.isNotEmpty()) Txt("Using: " + S.adhanName.ifEmpty { "Custom audio" }, 14.sp, g.text, bold = true)
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GoldButton("Choose from device") { audioPicker.launch(arrayOf("audio/*")) }
                if (S.adhanUri.isNotEmpty()) GlassChip("Use online voice", false, Modifier.align(Alignment.CenterVertically)) { S.setAdhan("", "") }
            }
            GlassChip("▶ Test Adhan now", false, Modifier.padding(top = 10.dp)) {
                ContextCompat.startForegroundService(ctx, Intent(ctx, AdhanService::class.java).putExtra("idx", 0))
            }
        }

        // Permissions
        Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Txt("Permissions", 16.sp, g.text, bold = true)
            Txt("Notifications: " + if (notifOk) "allowed ✓" else "blocked", 13.sp, g.dim)
            if (!notifOk) GoldButton("Allow notifications") {
                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                else ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))
            }
            Txt("Exact alarms: " + if (exactOk) "allowed ✓" else "not allowed (Adhan may be late)", 13.sp, g.dim)
            if (!exactOk && Build.VERSION.SDK_INT >= 31) GoldButton("Allow exact alarms") {
                ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}")))
            }
            Txt("For best reliability on some phones, also set Islam Sim to \"Unrestricted\" battery use.", 12.sp, g.dim)
        }
        Spacer(Modifier.height(8.dp))
    }

    if (showCities) CityPicker(onDismiss = { showCities = false }) { c ->
        S.setLocation("${c.name}, ${c.country}", c.lat, c.lng, c.tz, false)
        AdhanScheduler.scheduleNext(ctx); showCities = false
    }
}

private val Color_White = androidx.compose.ui.graphics.Color.White

@Composable
fun CityPicker(onDismiss: () -> Unit, onPick: (City) -> Unit) {
    val g = LocalGlass.current
    var q by remember { mutableStateOf("") }
    val list = remember(q) {
        val f = q.trim().lowercase()
        if (f.isEmpty()) CITIES else CITIES.filter { it.name.lowercase().contains(f) || it.country.lowercase().contains(f) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose city") },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, singleLine = true, placeholder = { Text("Search city or country") })
                LazyColumn(Modifier.height(320.dp)) {
                    items(list) { c ->
                        Column(Modifier.fillMaxWidth().clickable { onPick(c) }.padding(vertical = 10.dp)) {
                            Text(c.name, fontSize = 16.sp); Text(c.country, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
