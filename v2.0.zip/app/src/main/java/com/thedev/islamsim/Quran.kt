package com.thedev.islamsim

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class SurahMeta(val number: Int, val arabicName: String, val english: String, val meaning: String, val type: String, val ayahCount: Int)
class Hit(val surah: Int, val ayah: Int, val arabic: String, val translation: String?)

/**
 * Quran text is NEVER generated or edited by the app. It is downloaded once, unmodified, from
 * the AlQuran.cloud API (Tanzil Uthmani text + published translations), verified for completeness
 * (114 surahs / 6236 ayahs for the Arabic text) and cached on the device for offline reading.
 */
object Quran {
    const val ED_AR = "quran-uthmani"
    const val ED_EN = "en.sahih"       // Saheeh International
    const val ED_HA = "ha.gumi"        // Abubakar Mahmoud Gumi (Hausa)
    private const val TOTAL_AYAHS = 6236

    var status by mutableStateOf("idle")    // idle | loading | ready | error
    var error by mutableStateOf<String?>(null)
    var warning by mutableStateOf<String?>(null)
    var surahs by mutableStateOf<List<SurahMeta>>(emptyList())
    var arabic: List<List<String>> = emptyList()
    var english by mutableStateOf<List<List<String>>?>(null)
    var hausa by mutableStateOf<List<List<String>>?>(null)
    private var arIndex: List<List<String>>? = null

    suspend fun load(ctx: Context, force: Boolean = false) {
        if (status == "loading" || (status == "ready" && !force)) return
        status = "loading"; error = null; warning = null
        try {
            withContext(Dispatchers.IO) {
                if (force) File(ctx.filesDir, "quran").listFiles()?.forEach { it.delete() }
                val ar = readEdition(ctx, ED_AR, verifyTotal = true)
                val metas = ArrayList<SurahMeta>()
                val texts = ArrayList<List<String>>()
                val arr = JSONObject(ar).getJSONObject("data").getJSONArray("surahs")
                for (i in 0 until arr.length()) {
                    val s = arr.getJSONObject(i)
                    val ay = s.getJSONArray("ayahs")
                    metas.add(SurahMeta(s.getInt("number"), s.getString("name"), s.getString("englishName"),
                        s.getString("englishNameTranslation"), s.getString("revelationType"), ay.length()))
                    texts.add(List(ay.length()) { ay.getJSONObject(it).getString("text") })
                }
                arabic = texts; arIndex = null
                surahs = metas
                val warns = ArrayList<String>()
                english = try { parseTranslation(readEdition(ctx, ED_EN, false)) } catch (e: Exception) { warns.add("English translation unavailable offline yet."); null }
                hausa = try { parseTranslation(readEdition(ctx, ED_HA, false)) } catch (e: Exception) { warns.add("Hausa translation unavailable offline yet."); null }
                if (warns.isNotEmpty()) warning = warns.joinToString(" ")
            }
            status = "ready"
        } catch (e: Exception) {
            error = if (e is IOException) "Couldn't download the Quran text. Check your internet connection and try again."
            else "Quran data could not be read: ${e.message}"
            status = "error"
        }
    }

    private fun parseTranslation(json: String): List<List<String>> {
        val arr = JSONObject(json).getJSONObject("data").getJSONArray("surahs")
        return List(arr.length()) { i ->
            val ay = arr.getJSONObject(i).getJSONArray("ayahs")
            List(ay.length()) { ay.getJSONObject(it).getString("text") }
        }
    }

    private fun readEdition(ctx: Context, ed: String, verifyTotal: Boolean): String {
        val dir = File(ctx.filesDir, "quran").also { it.mkdirs() }
        val f = File(dir, "$ed.json")
        if (f.exists()) {
            val cached = f.readText()
            if (isValid(cached, verifyTotal)) return cached
            f.delete()
        }
        val conn = URL("https://api.alquran.cloud/v1/quran/$ed").openConnection() as HttpURLConnection
        conn.connectTimeout = 20000; conn.readTimeout = 60000
        try {
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (!isValid(text, verifyTotal)) throw IOException("Incomplete download")
            val tmp = File(dir, "$ed.tmp"); tmp.writeText(text, Charsets.UTF_8)
            if (!tmp.renameTo(f)) f.writeText(text, Charsets.UTF_8)
            return text
        } finally { conn.disconnect() }
    }

    private fun isValid(json: String, @Suppress("UNUSED_PARAMETER") verifyTotal: Boolean): Boolean = try {
        val arr = JSONObject(json).getJSONObject("data").getJSONArray("surahs")
        var total = 0
        for (i in 0 until arr.length()) total += arr.getJSONObject(i).getJSONArray("ayahs").length()
        arr.length() == 114 && total == TOTAL_AYAHS
    } catch (e: Exception) { false }

    private fun norm(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            if (c in '\u064B'..'\u065F' || c == '\u0670' || c in '\u06D6'..'\u06ED' || c == '\u0640') continue
            sb.append(when (c) { 'ٱ', 'أ', 'إ', 'آ' -> 'ا'; 'ى' -> 'ي'; else -> c })
        }
        return sb.toString()
    }

    fun search(q: String): List<Hit> {
        val query = q.trim()
        if (query.length < 2 || arabic.isEmpty()) return emptyList()
        val hits = ArrayList<Hit>()
        val isArabic = query.any { it in '\u0600'..'\u06FF' }
        if (isArabic) {
            val idx = arIndex ?: arabic.map { s -> s.map { norm(it) } }.also { arIndex = it }
            val nq = norm(query)
            loop@ for (s in idx.indices) for (a in idx[s].indices) {
                if (idx[s][a].contains(nq)) {
                    hits.add(Hit(s + 1, a + 1, arabic[s][a], english?.get(s)?.get(a)))
                    if (hits.size >= 80) break@loop
                }
            }
        } else {
            val lq = query.lowercase()
            val sources = listOfNotNull(english, hausa)
            loop@ for (s in arabic.indices) for (a in arabic[s].indices) {
                val m = sources.firstOrNull { it[s][a].lowercase().contains(lq) }
                if (m != null) {
                    hits.add(Hit(s + 1, a + 1, arabic[s][a], m[s][a]))
                    if (hits.size >= 80) break@loop
                }
            }
        }
        return hits
    }
}
