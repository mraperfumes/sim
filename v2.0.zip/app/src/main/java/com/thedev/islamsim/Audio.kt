package com.thedev.islamsim

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Hosts the ExoPlayer so recitation keeps playing with the screen off. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: android.content.Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady) stopSelf()
    }

    override fun onDestroy() {
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}

object Audio {
    const val RECITER_NAME = "Abdur-Rahman As-Sudais"
    var downloaded by mutableStateOf<Set<Int>>(emptySet())
    var progress by mutableStateOf<Map<Int, Float>>(emptyMap())

    fun urls(n: Int): List<String> = listOf(
        "https://cdn.islamic.network/quran/audio-surah/128/ar.abdurrahmaansudais/$n.mp3",
        "https://server11.mp3quran.net/sds/${n.toString().padStart(3, '0')}.mp3"
    )

    fun file(ctx: Context, n: Int) = File(File(ctx.filesDir, "audio").also { it.mkdirs() }, "sudais_$n.mp3")

    fun refresh(ctx: Context) {
        downloaded = (1..114).filter { file(ctx, it).let { f -> f.exists() && f.length() > 10_000 } }.toSet()
    }

    suspend fun firstReachable(n: Int): String? = withContext(Dispatchers.IO) {
        for (u in urls(n)) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.requestMethod = "HEAD"; c.connectTimeout = 8000; c.readTimeout = 8000
                val ok = c.responseCode in 200..299
                c.disconnect()
                if (ok) return@withContext u
            } catch (_: Exception) { }
        }
        null
    }

    suspend fun download(ctx: Context, n: Int): Boolean = withContext(Dispatchers.IO) {
        for (u in urls(n)) {
            val tmp = File(ctx.filesDir, "audio/sudais_$n.tmp")
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 30000
                if (c.responseCode !in 200..299) { c.disconnect(); continue }
                val total = c.contentLengthLong
                progress = progress + (n to 0f)
                tmp.parentFile?.mkdirs()
                c.inputStream.use { input ->
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(16 * 1024); var read: Int; var done = 0L
                        while (input.read(buf).also { read = it } >= 0) {
                            out.write(buf, 0, read); done += read
                            if (total > 0) progress = progress + (n to (done.toFloat() / total))
                        }
                    }
                }
                c.disconnect()
                if (tmp.length() < 10_000) throw IOException("Too small")
                val dest = file(ctx, n)
                if (dest.exists()) dest.delete()
                if (!tmp.renameTo(dest)) throw IOException("Rename failed")
                progress = progress - n
                downloaded = downloaded + n
                return@withContext true
            } catch (_: Exception) { tmp.delete() }
        }
        progress = progress - n
        false
    }

    fun delete(ctx: Context, n: Int) { file(ctx, n).delete(); downloaded = downloaded - n }
}

object Recitation {
    private var controller: MediaController? = null
    var isPlaying by mutableStateOf(false)
    var surah by mutableIntStateOf(0)
    var position by mutableLongStateOf(0L)
    var duration by mutableLongStateOf(0L)
    var buffering by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { Recitation.isPlaying = isPlaying }
        override fun onPlaybackStateChanged(state: Int) {
            buffering = state == Player.STATE_BUFFERING
            if (state == Player.STATE_ENDED) isPlaying = false
        }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            surah = mediaItem?.mediaId?.removePrefix("s")?.toIntOrNull() ?: 0
        }
        override fun onPlayerError(e: PlaybackException) {
            error = "Playback failed. Check your internet connection or download the Surah."
            isPlaying = false
        }
    }

    fun connect(ctx: Context) {
        if (controller != null) return
        val app = ctx.applicationContext
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                isPlaying = c.isPlaying
                surah = c.currentMediaItem?.mediaId?.removePrefix("s")?.toIntOrNull() ?: 0
            } catch (e: Exception) { error = "Audio player unavailable." }
        }, ContextCompat.getMainExecutor(app))
    }

    private suspend fun awaitController(): MediaController? {
        repeat(50) { controller?.let { return it }; delay(100) }
        return controller
    }

    suspend fun play(ctx: Context, n: Int, name: String) {
        error = null
        connect(ctx)
        val local = Audio.file(ctx, n)
        val uri: Uri = if (local.exists() && local.length() > 10_000) Uri.fromFile(local)
        else Uri.parse(Audio.firstReachable(n) ?: run { error = "No internet connection. Download this Surah to listen offline."; return })
        val item = MediaItem.Builder().setMediaId("s$n").setUri(uri)
            .setMediaMetadata(MediaMetadata.Builder().setTitle("Surah $name").setArtist(Audio.RECITER_NAME).build()).build()
        val c = awaitController() ?: run { error = "Audio player unavailable."; return }
        surah = n
        c.setMediaItem(item); c.prepare(); c.play()
    }

    fun toggle() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun seek(ms: Long) { controller?.seekTo(ms) }
    fun stop() { controller?.run { stop(); clearMediaItems() }; isPlaying = false; surah = 0 }

    fun tick() {
        val c = controller ?: return
        position = c.currentPosition.coerceAtLeast(0)
        duration = c.duration.let { if (it == C.TIME_UNSET) 0L else it.coerceAtLeast(0) }
    }
}
