package com.thedev.islamsim

import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        S.init(this)
        Recitation.connect(this)
        AdhanScheduler.scheduleNext(this)
        Ads.start(this)
        setContent { IslamSimTheme { AppRoot() } }
    }
}

@Composable
fun AppRoot() {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var reader by rememberSaveable { mutableIntStateOf(0) }
    var readerStart by rememberSaveable { mutableIntStateOf(0) }

    DisposableEffect(g.dark) {
        val style = if (g.dark) SystemBarStyle.dark(AColor.TRANSPARENT) else SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT)
        activity.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
        onDispose { }
    }
    LaunchedEffect(Unit) {
        Audio.refresh(ctx); AdhanLibrary.refresh(ctx)
        if (S.adhanUri.isEmpty()) AdhanLibrary.ensure(ctx, S.adhanOnlineId)
        Quran.load(ctx)
    }
    BackHandler(enabled = reader != 0 || tab != 0) { if (reader != 0) reader = 0 else tab = 0 }

    Box(Modifier.fillMaxSize()) {
        GlassBackground()
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) {
                if (reader != 0) {
                    Reader(surah = reader, startIndex = readerStart, onBack = { reader = 0 })
                } else {
                    Crossfade(targetState = tab, label = "tabs") { t ->
                        when (t) {
                            0 -> HomeTab(onNav = { tab = it }, onOpen = { s, i -> readerStart = i; reader = s })
                            1 -> QuranTab(onOpen = { s, i -> readerStart = i; reader = s })
                            2 -> PrayerTab()
                            else -> SettingsTab()
                        }
                    }
                }
            }
            if (reader == 0) NavBar(tab) { tab = it }
        }
    }
}

@Composable
fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    val g = LocalGlass.current
    val items = listOf("🏠" to "Home", "📖" to "Quran", "🕋" to "Prayer", "⚙️" to "Settings")
    Row(
        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp).glass(28.dp).padding(6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        items.forEachIndexed { i, (icon, label) ->
            val sel = i == selected
            Column(
                Modifier.weight(1f).clickable { onSelect(i) }.padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Txt(icon, 20.sp)
                Txt(label, 11.sp, if (sel) g.gold else g.dim, bold = sel)
            }
        }
    }
}
