package com.thedev.islamsim

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun SettingsTab() {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Txt("Settings", 24.sp, g.gold, bold = true)

        Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
            Txt("Theme", 16.sp, g.text, bold = true)
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassChip("System", S.theme == 0) { S.changeTheme(0) }
                GlassChip("Dark", S.theme == 1) { S.changeTheme(1) }
                GlassChip("Light", S.theme == 2) { S.changeTheme(2) }
            }
            Txt("Background", 12.sp, g.dim, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassChip("Emerald", !S.sapphireOn) { S.changeSapphireOn(false) }
                GlassChip(if (S.sapphireUnlocked) "Sapphire" else "Sapphire 🔒", S.sapphireOn && S.sapphireUnlocked) {
                    if (S.sapphireUnlocked) S.changeSapphireOn(true)
                }
            }
            if (!S.sapphireUnlocked) Txt("Unlock by supporting the app with one optional ad on the Home screen.", 12.sp, g.dim,
                modifier = Modifier.padding(top = 6.dp))
        }

        Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
            Txt("Quran reading", 16.sp, g.text, bold = true)
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassChip("English", S.showEn) { S.changeShowEn(!S.showEn) }
                GlassChip("Hausa", S.showHa) { S.changeShowHa(!S.showHa) }
            }
            Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Txt("Arabic size ${S.arabicSize.toInt()}", 14.sp, g.text, modifier = Modifier.weight(1f))
                GlassChip("A−", false) { S.changeArabicSize(S.arabicSize - 2) }
                GlassChip("A+", false) { S.changeArabicSize(S.arabicSize + 2) }
            }
            GlassChip("Re-download Quran text", false, Modifier.padding(top = 12.dp)) { scope.launch { Quran.load(ctx, true) } }
        }

        Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
            Txt("Privacy & ads", 16.sp, g.text, bold = true)
            Txt("Only optional rewarded ads are used. They never appear during Quran reading, recitation or Adhan.", 12.sp, g.dim,
                modifier = Modifier.padding(top = 4.dp))
            if (Ads.privacyOptionsRequired) GlassChip("Ad privacy options", false, Modifier.padding(top = 10.dp)) {
                Ads.showPrivacyOptions(ctx as android.app.Activity)
            }
        }

        Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
            Txt("About Islam Sim", 16.sp, g.text, bold = true)
            Txt("Version ${BuildConfig.VERSION_NAME}", 12.sp, g.dim, modifier = Modifier.padding(top = 4.dp))
            Txt("Quran text: Tanzil Uthmani text via AlQuran.cloud, shown unmodified. English: Saheeh International. " +
                "Hausa: Abubakar Mahmoud Gumi. Recitation: Abdur-Rahman As-Sudais. Prayer times: Adhan library. Adhan audio: AlAdhan.com / Islamic Network (personal use). " +
                "Always verify with a trusted mushaf.", 12.sp, g.dim, modifier = Modifier.padding(top = 6.dp))
        }
        Spacer(Modifier.height(8.dp))
    }
}
