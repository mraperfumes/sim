package com.thedev.islamsim

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class Glass(
    val dark: Boolean, val bgTop: Color, val bgBottom: Color, val card: Color, val cardHi: Color,
    val border: Color, val gold: Color, val text: Color, val dim: Color, val accent: Color
)

val EmeraldDark = Glass(true, Color(0xFF031A13), Color(0xFF0B3026), Color(0x2EFFFFFF), Color(0x47FFFFFF),
    Color(0x80D4B26A), Color(0xFFE2C378), Color(0xFFF6F1E3), Color(0xFFC9D4CC), Color(0xFF1FA67A))
val SapphireDark = Glass(true, Color(0xFF050B1F), Color(0xFF12225A), Color(0x2EFFFFFF), Color(0x47FFFFFF),
    Color(0x80D4B26A), Color(0xFFE2C378), Color(0xFFF4F2EA), Color(0xFFC6CCE0), Color(0xFF4C74E0))
val IvoryLight = Glass(false, Color(0xFFFFFDF6), Color(0xFFF0EAD8), Color(0xB3FFFFFF), Color(0xE6FFFFFF),
    Color(0xAAC9A24D), Color(0xFF8A6A1F), Color(0xFF17352A), Color(0xFF55675D), Color(0xFF14775A))
val SapphireLight = Glass(false, Color(0xFFF7F9FF), Color(0xFFE2E8F6), Color(0xB3FFFFFF), Color(0xE6FFFFFF),
    Color(0xAAC9A24D), Color(0xFF8A6A1F), Color(0xFF14213D), Color(0xFF55607A), Color(0xFF2B4C9B))

val LocalGlass = staticCompositionLocalOf { EmeraldDark }

@Composable
fun IslamSimTheme(content: @Composable () -> Unit) {
    val dark = when (S.theme) { 1 -> true; 2 -> false; else -> isSystemInDarkTheme() }
    val sap = S.sapphireOn && S.sapphireUnlocked
    val g = when {
        dark && sap -> SapphireDark
        dark -> EmeraldDark
        sap -> SapphireLight
        else -> IvoryLight
    }
    val scheme = if (dark) darkColorScheme(
        primary = g.gold, onPrimary = Color(0xFF1A1405), background = g.bgTop, surface = g.bgBottom,
        onSurface = g.text, onBackground = g.text
    ) else lightColorScheme(
        primary = g.gold, onPrimary = Color.White, background = g.bgTop, surface = g.bgBottom,
        onSurface = g.text, onBackground = g.text
    )
    CompositionLocalProvider(LocalGlass provides g) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/** Translucent "liquid glass" surface: soft gradient fill + thin gold edge. */
@Composable
fun Modifier.glass(radius: Dp = 22.dp): Modifier {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(radius)
    return this.clip(shape)
        .background(Brush.verticalGradient(listOf(g.cardHi, g.card)), shape)
        .border(1.dp, g.border, shape)
}

@Composable
fun GlassBackground() {
    val g = LocalGlass.current
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(g.bgTop, g.bgBottom)))) {
        Canvas(Modifier.fillMaxSize()) {
            val a = if (g.dark) 0.30f else 0.35f
            drawCircle(
                Brush.radialGradient(listOf(g.accent.copy(alpha = a), Color.Transparent),
                    center = Offset(size.width * 0.85f, size.height * 0.12f), radius = size.width * 0.75f),
                radius = size.width * 0.75f, center = Offset(size.width * 0.85f, size.height * 0.12f))
            drawCircle(
                Brush.radialGradient(listOf(g.gold.copy(alpha = a * 0.7f), Color.Transparent),
                    center = Offset(size.width * 0.05f, size.height * 0.7f), radius = size.width * 0.7f),
                radius = size.width * 0.7f, center = Offset(size.width * 0.05f, size.height * 0.7f))
        }
    }
}

@Composable
fun Txt(
    text: String, size: TextUnit = 15.sp, color: Color = LocalGlass.current.text, bold: Boolean = false,
    modifier: Modifier = Modifier, align: TextAlign? = null, font: FontFamily? = null, lineHeight: TextUnit = TextUnit.Unspecified
) {
    Text(text, modifier = modifier, color = color, fontSize = size, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        textAlign = align, fontFamily = font, lineHeight = lineHeight)
}

@Composable
fun GoldButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(14.dp)
    val bg = if (enabled) Brush.horizontalGradient(listOf(Color(0xFFE9CF8A), Color(0xFFC9A24D)))
    else Brush.horizontalGradient(listOf(g.card, g.card))
    Box(
        modifier.clip(shape).background(bg, shape).border(1.dp, g.border, shape)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { Txt(text, 14.sp, if (enabled) Color(0xFF1A1405) else g.dim, bold = true) }
}

@Composable
fun GlassChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(50)
    Box(
        modifier.clip(shape)
            .background(if (selected) g.gold.copy(alpha = 0.28f) else g.card, shape)
            .border(1.dp, if (selected) g.gold else g.border, shape)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { Txt(text, 13.sp, if (selected) g.gold else g.text, bold = selected) }
}

@Composable
fun arabicFont(): FontFamily {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    return remember {
        try {
            if (ctx.assets.list("fonts")?.contains("arabic.ttf") == true)
                FontFamily(androidx.compose.ui.text.font.Font("fonts/arabic.ttf", ctx.assets))
            else FontFamily.Default
        } catch (e: Exception) { FontFamily.Default }
    }
}
