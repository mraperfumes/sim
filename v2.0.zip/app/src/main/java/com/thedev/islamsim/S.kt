package com.thedev.islamsim

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*

/** App-wide settings. Compose-observable and persisted in SharedPreferences. */
object S {
    private var sp: SharedPreferences? = null

    var theme by mutableIntStateOf(0)              // 0 system, 1 dark, 2 light
    var sapphireUnlocked by mutableStateOf(false)  // unlocked by watching an optional rewarded ad
    var sapphireOn by mutableStateOf(false)
    var supportCount by mutableIntStateOf(0)

    var showEn by mutableStateOf(true)
    var showHa by mutableStateOf(false)
    var arabicSize by mutableFloatStateOf(30f)
    var lastSurah by mutableIntStateOf(0)
    var lastIndex by mutableIntStateOf(0)
    var bookmarks by mutableStateOf<Set<String>>(emptySet())

    var hasLoc by mutableStateOf(false)
    var locAuto by mutableStateOf(false)
    var locName by mutableStateOf("")
    var lat by mutableDoubleStateOf(21.4225)
    var lng by mutableDoubleStateOf(39.8262)
    var locTz by mutableStateOf("Asia/Riyadh")
    var method by mutableStateOf("MUSLIM_WORLD_LEAGUE")
    var hanafi by mutableStateOf(false)

    var master by mutableStateOf(true)
    var prayerMask by mutableIntStateOf(31)
    var adhanUri by mutableStateOf("")
    var adhanName by mutableStateOf("")
    var adhanOnlineId by mutableStateOf("a7")

    @Synchronized
    fun init(ctx: Context) {
        if (sp != null) return
        val p = ctx.applicationContext.getSharedPreferences("islamsim", Context.MODE_PRIVATE)
        sp = p
        theme = p.getInt("theme", 0)
        sapphireUnlocked = p.getBoolean("sapphireUnlocked", false)
        sapphireOn = p.getBoolean("sapphireOn", false)
        supportCount = p.getInt("supportCount", 0)
        showEn = p.getBoolean("showEn", true)
        showHa = p.getBoolean("showHa", false)
        arabicSize = p.getFloat("arabicSize", 30f)
        lastSurah = p.getInt("lastSurah", 0)
        lastIndex = p.getInt("lastIndex", 0)
        bookmarks = p.getStringSet("bm", emptySet())?.toSet() ?: emptySet()
        hasLoc = p.getBoolean("hasLoc", false)
        locAuto = p.getBoolean("locAuto", false)
        locName = p.getString("locName", "") ?: ""
        lat = Double.fromBits(p.getLong("lat", 21.4225.toRawBits()))
        lng = Double.fromBits(p.getLong("lng", 39.8262.toRawBits()))
        locTz = p.getString("locTz", "Asia/Riyadh") ?: "Asia/Riyadh"
        method = p.getString("method", "MUSLIM_WORLD_LEAGUE") ?: "MUSLIM_WORLD_LEAGUE"
        hanafi = p.getBoolean("hanafi", false)
        master = p.getBoolean("master", true)
        prayerMask = p.getInt("prayerMask", 31)
        adhanUri = p.getString("adhanUri", "") ?: ""
        adhanName = p.getString("adhanName", "") ?: ""
        adhanOnlineId = p.getString("adhanOnlineId", "a7") ?: "a7"
    }

    private fun save(block: SharedPreferences.Editor.() -> Unit) {
        sp?.edit()?.apply(block)?.apply()
    }

    fun changeTheme(v: Int) { theme = v; save { putInt("theme", v) } }
    fun changeSapphireOn(v: Boolean) { sapphireOn = v; save { putBoolean("sapphireOn", v) } }
    fun rewardEarned() {
        sapphireUnlocked = true; supportCount += 1
        save { putBoolean("sapphireUnlocked", true); putInt("supportCount", supportCount) }
    }
    fun changeShowEn(v: Boolean) { showEn = v; save { putBoolean("showEn", v) } }
    fun changeShowHa(v: Boolean) { showHa = v; save { putBoolean("showHa", v) } }
    fun changeArabicSize(v: Float) { arabicSize = v.coerceIn(22f, 48f); save { putFloat("arabicSize", arabicSize) } }
    fun setLast(surah: Int, index: Int) {
        lastSurah = surah; lastIndex = index
        save { putInt("lastSurah", surah); putInt("lastIndex", index) }
    }
    fun toggleBookmark(surah: Int, ayah: Int) {
        val k = "$surah:$ayah"
        bookmarks = if (k in bookmarks) bookmarks - k else bookmarks + k
        val copy = HashSet(bookmarks)
        save { putStringSet("bm", copy) }
    }
    fun setLocation(name: String, la: Double, ln: Double, tz: String, auto: Boolean) {
        locName = name; lat = la; lng = ln; locTz = tz; hasLoc = true; locAuto = auto
        save {
            putString("locName", name); putLong("lat", la.toRawBits()); putLong("lng", ln.toRawBits())
            putString("locTz", tz); putBoolean("hasLoc", true); putBoolean("locAuto", auto)
        }
    }
    fun changeMethod(v: String) { method = v; save { putString("method", v) } }
    fun changeHanafi(v: Boolean) { hanafi = v; save { putBoolean("hanafi", v) } }
    fun changeMaster(v: Boolean) { master = v; save { putBoolean("master", v) } }
    fun prayerOn(i: Int) = (prayerMask shr i) and 1 == 1
    fun setPrayer(i: Int, on: Boolean) {
        prayerMask = if (on) prayerMask or (1 shl i) else prayerMask and (1 shl i).inv()
        save { putInt("prayerMask", prayerMask) }
    }
    fun changeAdhanOnline(id: String) { adhanOnlineId = id; save { putString("adhanOnlineId", id) } }
    fun setAdhan(uri: String, name: String) {
        adhanUri = uri; adhanName = name
        save { putString("adhanUri", uri); putString("adhanName", name) }
    }
}
