package com.thedev.islamsim

import android.app.Application

class IslamSimApp : Application() {
    override fun onCreate() {
        super.onCreate()
        S.init(this)
        Notifier.ensureChannels(this)
    }
}
