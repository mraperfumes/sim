package com.thedev.islamsim

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun rememberNow(): Long {
    var n by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(1000); n = System.currentTimeMillis() } }
    return n
}

@Composable
fun CountdownRing(progress: Float, title: String, sub: String, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    val anim by animateFloatAsState(progress.coerceIn(0f, 1f), tween(900), label = "ring")
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0.25f, 0.6f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    Box(modifier.size(190.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 12.dp.toPx(); val inset = stroke / 2 + 6.dp.toPx()
            val sz = Size(size.width - inset * 2, size.height - inset * 2)
            drawCircle(g.gold.copy(alpha = pulse * 0.25f), radius = size.minDimension / 2)
            drawArc(g.border.copy(alpha = 0.35f), 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(stroke))
            drawArc(Brush.sweepGradient(listOf(g.accent, g.gold, g.accent)), -90f, 360f * anim, false,
                Offset(inset, inset), sz, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Txt(sub, 12.sp, g.dim)
            Txt(title, 28.sp, g.text, bold = true)
        }
    }
}

@Composable
fun HomeTab(onNav: (Int) -> Unit, onOpen: (Int, Int) -> Unit) {
    val g = LocalGlass.current
    val now = rememberNow()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Preserved branding from the original Islam Sim home screen
        Column(Modifier.fillMaxWidth().glass(26.dp).padding(20.dp)) {
            Txt("☾ ISLAM SIM", 26.sp, g.gold, bold = true)
            Txt("Your Islamic companion", 14.sp, g.dim, modifier = Modifier.padding(top = 4.dp))
            Txt("السلام عليكم", 24.sp, g.text, modifier = Modifier.padding(top = 10.dp))
            Txt("Assalamu Alaikum", 14.sp, g.dim)
        }

        // Prayer countdown
        Column(Modifier.fillMaxWidth().glass().clickable { onNav(2) }.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (!S.hasLoc) {
                Txt("Set your location to see prayer times", 15.sp, g.text, bold = true, align = TextAlign.Center)
                Txt("Tap to choose GPS or a city", 13.sp, g.dim, modifier = Modifier.padding(top = 4.dp))
            } else {
                val hour = now / 3_600_000L
                val line = remember(hour, S.lat, S.lng, S.method, S.hanafi, S.locTz) { PrayerCalc.timeline(now) }
                val next = line.firstOrNull { it.second > now }
                val prev = line.lastOrNull { it.second <= now }
                if (next != null) {
                    val left = (next.second - now) / 1000
                    val span = if (prev != null) (next.second - prev.second).toFloat() else 1f
                    val prog = if (prev != null && span > 0) (now - prev.second) / span else 0f
                    CountdownRing(prog, String.format(Locale.US, "%02d:%02d:%02d", left / 3600, (left % 3600) / 60, left % 60),
                        "until ${PrayerCalc.NAMES[next.first]}")
                    Txt("${PrayerCalc.NAMES[next.first]} • ${PrayerCalc.fmt(next.second)}", 16.sp, g.gold, bold = true,
                        modifier = Modifier.padding(top = 8.dp))
                    Txt(S.locName, 13.sp, g.dim)
                }
            }
        }

        // Continue reading
        if (S.lastSurah in 1..114 && Quran.surahs.size == 114) {
            val m = Quran.surahs[S.lastSurah - 1]
            Row(Modifier.fillMaxWidth().glass().clickable { onOpen(S.lastSurah, S.lastIndex) }.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt("Continue reading", 12.sp, g.dim)
                    Txt("${m.english} • Ayah ${S.lastIndex + 1}", 17.sp, g.text, bold = true)
                }
                Txt(m.arabicName, 20.sp, g.gold, font = arabicFont())
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f).glass().clickable { onNav(1) }.padding(18.dp)) {
                Txt("📖", 26.sp); Txt("Holy Quran", 16.sp, g.text, bold = true, modifier = Modifier.padding(top = 6.dp))
                Txt("114 Surahs • Sudais", 12.sp, g.dim)
            }
            Column(Modifier.weight(1f).glass().clickable { onNav(2) }.padding(18.dp)) {
                Txt("🕋", 26.sp); Txt("Prayer times", 16.sp, g.text, bold = true, modifier = Modifier.padding(top = 6.dp))
                Txt("Adhan & alarms", 12.sp, g.dim)
            }
        }
        SupportCard()
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
fun SupportCard() {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val activity = ctx as android.app.Activity
    val busy = Recitation.isPlaying || AdhanState.active
    Column(Modifier.fillMaxWidth().glass().padding(18.dp)) {
        Txt("Support Islam Sim", 16.sp, g.text, bold = true)
        Txt(if (S.sapphireUnlocked) "Thank you for your support! Sapphire theme is unlocked (Settings)."
        else "Optionally watch one short ad to support development and unlock the Sapphire background. Totally optional.",
            13.sp, g.dim, modifier = Modifier.padding(top = 4.dp, bottom = 10.dp))
        val label = when {
            busy -> "Available when audio isn't playing"
            Ads.ready -> "Watch an ad to support us"
            Ads.loading -> "Loading…"
            else -> "Ad unavailable – retry"
        }
        GoldButton(label, enabled = !busy && (Ads.ready || (!Ads.loading))) {
            if (Ads.ready) Ads.show(activity) { S.rewardEarned() } else Ads.load(ctx)
        }
        Ads.message?.let { Txt(it, 12.sp, g.dim, modifier = Modifier.padding(top = 6.dp)) }
    }
}
