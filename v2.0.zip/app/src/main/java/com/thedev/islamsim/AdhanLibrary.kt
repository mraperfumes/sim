package com.thedev.islamsim

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class AdhanVoice(val id: String, val name: String, val url: String)

/**
 * Real Adhan recordings published for download by AlAdhan.com (Islamic Network): https://aladhan.com/download-adhans
 * They are downloaded to the phone once, then played locally so the Adhan works offline and with the app closed.
 */
object AdhanLibrary {
    private const val BASE = "https://cdn.aladhan.com/audio/adhans/"
    val VOICES = listOf(
        AdhanVoice("a7", "Mishary Rashid Alafasy", BASE + "a7.mp3"),
        AdhanVoice("a9", "Mishary Rashid Alafasy (second)", BASE + "a9.mp3"),
        AdhanVoice("a4", "Mishary Alafasy – Dubai One TV", BASE + "a4.mp3"),
        AdhanVoice("a1", "Ahmad al-Nafees", BASE + "a1.mp3"),
        AdhanVoice("a11", "Mansour Al-Zahrani", BASE + "a11-mansour-al-zahrani.mp3"),
        AdhanVoice("a2", "Hafiz Mustafa Özcan (Turkey)", BASE + "a2.mp3")
    )

    var downloaded by mutableStateOf<Set<String>>(emptySet())
    var busy by mutableStateOf<String?>(null)
    var error by mutableStateOf<String?>(null)

    fun file(ctx: Context, id: String) = File(File(ctx.filesDir, "adhan").also { it.mkdirs() }, "$id.mp3")

    fun refresh(ctx: Context) {
        downloaded = VOICES.filter { file(ctx, it.id).let { f -> f.exists() && f.length() > 20_000 } }.map { it.id }.toSet()
    }

    /** Makes sure the voice is on the device. Returns true when ready. */
    suspend fun ensure(ctx: Context, id: String): Boolean {
        if (id in downloaded) return true
        val voice = VOICES.firstOrNull { it.id == id } ?: return false
        if (busy != null) return false
        busy = id; error = null
        val ok = withContext(Dispatchers.IO) {
            val tmp = File(ctx.filesDir, "adhan/$id.tmp")
            try {
                tmp.parentFile?.mkdirs()
                val c = URL(voice.url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 30000
                if (c.responseCode !in 200..299) { c.disconnect(); return@withContext false }
                c.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                c.disconnect()
                if (tmp.length() < 20_000) { tmp.delete(); return@withContext false }
                val dest = file(ctx, id)
                if (dest.exists()) dest.delete()
                tmp.renameTo(dest)
            } catch (e: Exception) { tmp.delete(); false }
        }
        busy = null
        if (ok) refresh(ctx) else error = "Couldn't download the Adhan. Check your internet connection and try again."
        return ok
    }
}
