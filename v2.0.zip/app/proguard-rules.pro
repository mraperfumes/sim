# Release build currently has minify disabled. Rules kept for future use.
