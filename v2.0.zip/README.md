# Islam Sim v2.0 (upgrade)

Package: `com.thedev.islamsim` · Native Kotlin + Jetpack Compose · minSdk 23 / targetSdk 35

## GitHub setup
1. Upload ALL files in this folder to your repo (keep `.github/workflows/android.yml`).
2. AdMob IDs are already set in the workflow (release build only; debug uses Google test ads).
   Optional signing secrets under Repo > Settings > Secrets and variables > Actions:
   - `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` – without them the release APK is debug-signed (installable, not Play-Store ready).
3. Actions > "Build Islam Sim APK" > Run workflow. Download the APK from the run's Artifacts.

## Adhan audio
The app downloads a real Adhan (default: Mishary Alafasy) from AlAdhan.com on first launch and stores it on the phone,
so it plays offline. Users can pick other voices or their own file under Prayer.

## Notes
- Quran text is downloaded once from AlQuran.cloud (Tanzil Uthmani), verified (114 surahs / 6236 ayahs) and cached offline.
- Debug builds always use Google test ad IDs. Never tap your own live ads.
- `legacy/index.html` is your original starter page (kept for reference).
